
document.addEventListener('DOMContentLoaded', () => {
    console.log('Portfolio đã tải thành công!');

    const currentPage = location.pathname;

    console.log('Trang hiện tại:', currentPage);
});
